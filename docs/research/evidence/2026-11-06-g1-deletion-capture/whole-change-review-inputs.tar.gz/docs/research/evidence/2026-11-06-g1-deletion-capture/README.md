# 删除目标原子捕获与候选备份清单证据

本目录仅收录 2026-11-06 当前批次的新证据。此前 4,680 个证据文件由 `baseline.json` 固定，任何旧结果均不覆盖。完整前后行含合成身份和测试地址，不含家庭内容。

当前阶段：Task 1 实现及修复复审通过；Task 2 实现、独立审查、父级原生复验与完整门禁通过，整批审查和归档待收口。

## 删除捕获

- [Task 1 初始报告](reviews/task-1-report.md)、[初审](reviews/task-1-review.md)、[修复报告](reviews/task-1-fixed-report.md)、[限定复审](reviews/task-1-fix-1-review.md)。I1 合法未登记会话、I2 无关正文序列化两项问题均已解决。
- [修复后原生结果](native-1793934773961-cfab3e45-06f7-4191-a5a7-436dae09ca50/results.json)：16 组／699 条断言，8 次真实锁等待，12 类故障注入完整回滚。保存完整行、原始来源坐标及合成字节；实际 service-role 连接调用 SQL 和编译后的应用适配器。
- [定向 Jest](task1-fix1-focused-final.json)：2 套／45 项；[根 ESLint](task1-fix1-root-eslint-final.json)及[模块语法检查](task1-fix1-syntax-and-whitespace.json)通过。各命令 JSON 包含起止源码指纹及 `.log.gz` 的压缩/原始摘要。
- [未登记会话 RED](native-fix1-red-1793934408307-49608342-392c-4f02-bf36-8f2fa50622b9/results.json)和[GREEN](native-fix1-1793934592700-47203a00-69ac-4817-b249-b6a8c60ffb9c/results.json)均保留。
- [序列化成本 RED](snapshot-cost-red-1793934655909-9152134f-9065-4860-a17f-38c45ec61b5d/results.json)和[GREEN](snapshot-cost-1793934664953-d05261e9-a122-4da1-acbb-abb6c9a1edea/results.json)：0／8／32 MiB 无关正文均不进入修复后的序列化。完整行以 gzip 保存；透明探针与实际 SQL 调用分开记录，不构成吞吐资格。

## 候选备份清单兼容

- [Task 2 报告](reviews/task-2-report.md)、[七文件补丁](reviews/task-2.patch)、[源码摘要](reviews/task-2-hashes.json)。生产仅扩展候选桶类型/白名单，另登记新迁移文件顺序。
- [原生 RED](native-backup-1793935620832-01c63300-6229-4178-bc88-f594ea72d9b1/results.json)、[原生 GREEN](native-backup-1793935677873-38321e13-9544-495d-86a7-10fc7947f578/results.json)：实际删除 RPC 的目标进入两验证器和 CLI。目录保存完整 capture、manifest、tombstones、兼容结果、非法输入结果与逐件摘要。
- [定向 Jest](task2-jest-green-1.json) 37 项、[Node](task2-infra-green-1.json) 17 项通过。Node 包含 7 项部署/迁移清单检查，不能据此认定完整迁移链执行通过。
- 父级冻结源码独立复验：[删除 699 断言](native-1793935758219-bdb59613-e1ca-4ed6-93f3-48aca8683817/results.json)、[备份 82 断言](native-backup-1793935759391-b9e5a10b-441b-4d24-b6bc-16c9624b13f5/results.json)。对应 [capture 命令](final-native-capture-01.json)／[backup 命令](final-native-backup-01.json)均退出 0、源码无漂移、临时资源已清理。

## 完整门禁与审查

- [完整门禁](final-gate-01.json)及其压缩日志：Web 160／3259、shared 4／16、infra 23、184 页构建，exit 0，903 个受测源码起止无漂移。
- [生成文件恢复](next-env-restore.json)：只恢复已知 next-env 引用，恢复后字节与本批接手基线相同。
- [Task 2 独立审查](reviews/task-2-review.md)：规格和质量 Approved，无待修项；完整行、实际 CLI 和全部证据摘要独立核对。
- 整批审查及最终源码归档/完整性回执待收口。

## 证据边界

本地 PG17 fixture 使用实际删除目标 DDL 和录音迁移，基础 auth/project/storage 环境仍为合成构造；应用 SQL transport 替代真实 PostgREST。它不证明完整迁移链、线上权限配置或真机行为。后续备份验证仅证明清单及墓碑存活集合兼容，不授予对象备份/恢复、物理删除或 GC 资格。`g1MilestoneSatisfied` 和 `pushConditionSatisfied` 继续为 false。
