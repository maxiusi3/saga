export const FOUNDATION = 'supabase/migrations/20261024000001_p1_foundation_and_reconciliation.sql'
export const SEAL = 'supabase/migrations/20261102000001_recording_seal_manifest.sql'
export const LEASE = 'supabase/migrations/20261103000001_recording_worker_leases.sql'
export const USER = '11111111-1111-4111-8111-111111111111'
export const OTHER = '22222222-2222-4222-8222-222222222222'
export const PROJECT = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
export const STORY = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc'

export async function setup(h, source) {
  const foundation = await source(FOUNDATION)
  await h.db.query(`
    CREATE SCHEMA auth;
    CREATE ROLE anon LOGIN NOSUPERUSER NOBYPASSRLS;
    CREATE ROLE authenticated LOGIN NOSUPERUSER NOBYPASSRLS;
    CREATE ROLE service_role LOGIN NOSUPERUSER NOBYPASSRLS;
    CREATE ROLE metadata_reader LOGIN NOSUPERUSER NOBYPASSRLS;
    GRANT USAGE ON SCHEMA public, auth TO anon, authenticated, service_role, metadata_reader;
    CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS
      $$ SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid $$;
    CREATE TABLE auth.users (id uuid PRIMARY KEY);
    CREATE TABLE public.projects (id uuid PRIMARY KEY, facilitator_id uuid REFERENCES auth.users(id));
    CREATE TABLE public.project_roles (id uuid PRIMARY KEY DEFAULT gen_random_uuid(), project_id uuid REFERENCES public.projects(id),
      user_id uuid REFERENCES auth.users(id), role text, status text, UNIQUE(project_id, user_id));
    CREATE TABLE public.project_members (project_id uuid REFERENCES public.projects(id), user_id uuid REFERENCES auth.users(id), status text);
    CREATE TABLE public.stories (id uuid PRIMARY KEY, project_id uuid REFERENCES public.projects(id), storyteller_id uuid REFERENCES auth.users(id));
    INSERT INTO auth.users VALUES ('${USER}'), ('${OTHER}');
    INSERT INTO public.projects VALUES ('${PROJECT}', '${OTHER}');
    INSERT INTO public.project_roles (project_id, user_id, role, status) VALUES ('${PROJECT}', '${USER}', 'storyteller', 'active');
    INSERT INTO public.stories VALUES ('${STORY}', '${PROJECT}', '${USER}');
  `)
  const tables = ['media_assets', 'deletion_requests', 'processing_jobs', 'processing_attempts', 'recording_sessions', 'recording_chunks']
  h.report.fixture = { syntheticPrerequisites: ['auth.users', 'auth.uid()', 'projects', 'project_roles', 'project_members', 'stories'],
    exactFoundationTables: tables, fullMigrations: [SEAL, LEASE], livePostgrest: false, liveStorage: false }
  for (const table of tables) {
    const ddl = foundation.match(new RegExp(`CREATE TABLE IF NOT EXISTS public\\.${table} \\([\\s\\S]*?\n\\);`))?.[0]
    h.ok(ddl, `exact foundation ${table} DDL found`)
    await h.db.query(ddl)
  }
  for (const name of ['is_project_facilitator', 'is_active_project_member']) {
    const ddl = foundation.match(new RegExp(`CREATE OR REPLACE FUNCTION public\\.${name}\\([\\s\\S]*?\n\\$\\$;`))?.[0]
    h.ok(ddl, `exact foundation ${name} found`)
    await h.db.query(ddl)
  }
  await h.db.query('GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role')
  await h.db.query(await source(SEAL))
}
