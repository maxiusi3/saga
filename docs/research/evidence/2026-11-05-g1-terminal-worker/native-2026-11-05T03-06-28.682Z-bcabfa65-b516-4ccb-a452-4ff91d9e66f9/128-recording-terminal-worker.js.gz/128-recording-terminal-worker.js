"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.finalizeLeasedRecordingJob = finalizeLeasedRecordingJob;
const recording_candidate_worker_1 = require("./recording-candidate-worker");
const recording_job_worker_1 = require("./recording-job-worker");
const recording_job_finalization_1 = require("./recording-job-finalization");
const recording_processing_error_1 = require("./recording-processing-error");
/** One supervised attempt; an unavailable response never authorizes replay or cleanup. */
async function finalizeLeasedRecordingJob(jobId, options) {
    try {
        // Retain the caller's original cancellation and settings across all awaits,
        // including the handoff after the supervisor aborts its own finished scope.
        const snapshot = { ...options, ffmpeg: { ...options.ffmpeg } };
        const result = await (0, recording_job_worker_1.withRecordingJobLease)(jobId, snapshot, async (context) => {
            const outcome = await (0, recording_candidate_worker_1.prepareRecordingJobCandidateOutcome)(jobId, snapshot, context);
            if (outcome.status === 'preparation_failed') {
                if (outcome.consumerStarted || !(0, recording_processing_error_1.isRecordingProcessingError)(outcome.error) || outcome.error.disposition !== 'permanent') {
                    throw new Error('recording_worker_unavailable');
                }
                return { status: 'permanent_failure', error: outcome.error, rpcTimeoutMs: context.rpcTimeoutMs };
            }
            return { ...outcome, rpcTimeoutMs: context.rpcTimeoutMs };
        });
        // Owned work, heartbeat drain and the final live-lease check have completed.
        // Terminal mutation must stay outside the supervisor: it invalidates the lease.
        const rpc = { admin: snapshot.admin, signal: snapshot.signal, timeoutMs: result.rpcTimeoutMs };
        return result.status === 'permanent_failure'
            ? await (0, recording_job_finalization_1.failRecordingJob)(result.lease, result.error, rpc)
            : await (0, recording_job_finalization_1.publishRecordingJob)(result.lease, result.candidate, rpc);
    }
    catch {
        throw new Error('recording_worker_unavailable');
    }
}
