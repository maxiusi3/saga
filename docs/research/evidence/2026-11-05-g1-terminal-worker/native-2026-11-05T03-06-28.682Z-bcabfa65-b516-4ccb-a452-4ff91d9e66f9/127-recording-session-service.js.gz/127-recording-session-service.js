"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_MAX_RECORDING_INPUT_BYTES = void 0;
exports.prepareRecordingSessionSeal = prepareRecordingSessionSeal;
exports.executeRecordingMergeJobAttempt = executeRecordingMergeJobAttempt;
const crypto_1 = require("crypto");
const consent_deletion_1 = require("./consent-deletion");
const processing_jobs_1 = require("./processing-jobs");
const recording_merge_1 = require("./recording-merge");
const recording_merge_executor_1 = require("./recording-merge-executor");
const recording_processing_error_1 = require("./recording-processing-error");
exports.DEFAULT_MAX_RECORDING_INPUT_BYTES = 100 * 1024 * 1024;
function recordingAssetId(input) {
    // UUIDv8 identity pins one actor/project/capture independently of changing manifest bytes.
    const bytes = (0, crypto_1.createHash)('sha256').update(JSON.stringify([
        'saga-recording-asset-v1', input.projectId, input.sessionId, input.actorId,
    ])).digest().subarray(0, 16);
    bytes[6] = (bytes[6] & 0x0f) | 0x80;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = bytes.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function prepareRecordingSessionSeal(input) {
    const allowed = (0, consent_deletion_1.isActionAllowed)('record_own_story', {
        actorId: input.actorId,
        active: input.actorActive,
        role: input.actorRole,
        storyOwnerId: input.actorId,
        isDeletionBlocked: input.isDeletionBlocked,
    });
    if (!allowed) {
        throw new Error('Actor is not permitted to seal a recording session in this project');
    }
    const assetId = input.assetId?.trim() || recordingAssetId(input);
    const jobId = input.jobId?.trim() || (0, crypto_1.randomUUID)();
    const inputVersion = input.inputVersion ?? 1;
    const processorVersion = input.processorVersion ?? 'ffmpeg-merge-v1';
    const parameterVersion = input.parameterVersion ?? 'default';
    const maxInputBytes = input.maxInputBytes ?? exports.DEFAULT_MAX_RECORDING_INPUT_BYTES;
    const task = (0, recording_merge_1.buildRecordingMergeTaskInput)({
        projectId: input.projectId,
        sessionId: input.sessionId,
        assetId,
        inputVersion,
        processorVersion,
        parameterVersion,
        mimeType: input.mimeType,
        chunks: input.chunks,
    });
    if (task.totalInputBytes > maxInputBytes) {
        throw new Error('recording_quota_exceeded: total chunk bytes exceed project recording limit');
    }
    const objectKey = `${input.actorId}/projects/${task.projectId}/assets/${assetId}/original`;
    const assetRecord = {
        id: assetId,
        project_id: task.projectId,
        story_id: input.storyId ?? null,
        created_by: input.actorId,
        bucket: 'audio-recordings',
        object_key: objectKey,
        kind: 'original_audio',
        mime_type: task.mimeType,
        byte_size: task.totalInputBytes,
        state: 'verifying',
        version: inputVersion,
        idempotency_key: task.idempotencyKey,
    };
    const jobSnapshot = {
        id: jobId,
        projectId: task.projectId,
        assetId,
        state: 'queued',
        inputVersion,
        jobType: 'recording_merge',
        processorVersion,
        modelConfigVersion: 'none',
        parameterVersion,
        attemptCount: 0,
        maxAttempts: input.maxAttempts ?? 3,
        notBefore: null,
        leaseOwner: null,
        leaseExpiresAt: null,
        cancelRequestedAt: null,
        deletionRequestedAt: input.isDeletionBlocked ? new Date().toISOString() : null,
        errorCode: null,
        resultRef: null,
    };
    return { task, assetRecord, jobSnapshot };
}
async function executeRecordingMergeJobAttempt(job, task, options) {
    const leased = (0, processing_jobs_1.claimProcessingJob)(job, {
        workerId: options.workerId,
        now: options.now,
        leaseMs: options.leaseMs,
    });
    (0, processing_jobs_1.assertProcessingJobTransition)(leased.state, 'running');
    const running = { ...leased, state: 'running' };
    try {
        const readyResult = await (0, recording_merge_executor_1.withVerifiedRecordingMerge)(task, {
            readChunk: options.readChunk,
            decodeAudio: options.decodeAudio,
            maxInputBytes: options.maxInputBytes ?? exports.DEFAULT_MAX_RECORDING_INPUT_BYTES,
            signal: options.signal,
        }, async (artifact) => {
            if (await options.isCancelledOrTombstoned?.()) {
                throw new Error('recording_merge_cancelled_before_publish');
            }
            await options.uploadMergedObject({
                bucket: 'audio-recordings',
                objectKey: options.targetObjectKey,
                filePath: artifact.filePath,
                mimeType: artifact.mimeType,
                byteSize: artifact.completion.outputByteSize,
                sha256: artifact.completion.outputSha256,
            });
            if (await options.isCancelledOrTombstoned?.()) {
                throw new Error('recording_merge_cancelled_before_publish');
            }
            return (0, recording_merge_1.verifyRecordingMergeCompletion)(task, artifact.completion);
        });
        const succeeded = (0, processing_jobs_1.completeProcessingJob)(running, options.now, readyResult.assetId);
        return {
            status: 'ready',
            readyResult,
            job: succeeded,
            canClearLocalDrafts: true,
        };
    }
    catch (err) {
        if (err instanceof Error && err.message === 'recording_merge_cancelled_before_publish') {
            const cancelled = (0, processing_jobs_1.requestProcessingJobCancellation)(running, options.now);
            return {
                status: 'cancelled',
                errorCode: 'cancelled_or_tombstoned',
                job: cancelled,
                canClearLocalDrafts: false,
            };
        }
        if ((0, recording_processing_error_1.isRecordingProcessingError)(err) && err.disposition === 'permanent') {
            (0, processing_jobs_1.assertProcessingJobTransition)(running.state, 'failed');
            const failed = {
                ...running,
                state: 'failed',
                leaseOwner: null,
                leaseExpiresAt: null,
                notBefore: null,
                errorCode: err.code,
            };
            return {
                status: 'quarantined',
                errorCode: err.code,
                job: failed,
                canClearLocalDrafts: false,
            };
        }
        const retried = (0, processing_jobs_1.retryProcessingJob)(running, {
            now: options.now,
            errorCode: (0, recording_processing_error_1.isRecordingProcessingError)(err)
                ? err.code
                : err instanceof Error && err.message
                    ? err.message
                    : 'transient_merge_error',
            delayMs: options.retryDelayMs ?? 5000,
        });
        return {
            status: retried.state === 'failed' ? 'failed' : 'retry_wait',
            errorCode: retried.errorCode ?? 'transient_merge_error',
            job: retried,
            canClearLocalDrafts: false,
        };
    }
}
