"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyRecordingJobInput = verifyRecordingJobInput;
exports.withVerifiedRecordingJobInput = withVerifiedRecordingJobInput;
const recording_job_input_1 = require("./recording-job-input");
const recording_audio_decoder_1 = require("./recording-audio-decoder");
const recording_merge_executor_1 = require("./recording-merge-executor");
const recording_session_service_1 = require("./recording-session-service");
const recording_processing_error_1 = require("./recording-processing-error");
function unavailable() { return new Error('recording_input_unavailable'); }
function ioScope(caller, timeoutMs) {
    const controller = new AbortController();
    const abort = () => controller.abort(unavailable());
    caller?.addEventListener('abort', abort, { once: true });
    if (caller?.aborted)
        abort();
    const timer = setTimeout(abort, timeoutMs);
    return {
        signal: controller.signal,
        abort,
        async wait(pending) {
            let rejectAbort = () => { };
            const interrupted = new Promise((_, reject) => {
                rejectAbort = () => reject(unavailable());
                controller.signal.addEventListener('abort', rejectAbort, { once: true });
                if (controller.signal.aborted)
                    rejectAbort();
            });
            try {
                return await Promise.race([pending, interrupted]);
            }
            finally {
                controller.signal.removeEventListener('abort', rejectAbort);
            }
        },
        close() { clearTimeout(timer); caller?.removeEventListener('abort', abort); abort(); },
    };
}
async function closeBody(response, reader) {
    if (!reader && !response?.body)
        return;
    let timer;
    try {
        await Promise.race([
            reader ? reader.cancel() : response.body.cancel(),
            new Promise((_, reject) => { timer = setTimeout(() => reject(unavailable()), 1000); }),
        ]);
    }
    finally {
        clearTimeout(timer);
        reader?.releaseLock();
    }
}
/** Read-only compatibility entry; evidence never authorizes local draft cleanup. */
async function verifyRecordingJobInput(jobId, options) {
    const completion = await withVerifiedRecordingJobInput(jobId, options, async (artifact) => artifact.completion);
    return { status: 'input_verified', jobId, completion, canClearLocalDrafts: false };
}
/** The artifact belongs to this scope and is removed after consume settles.
 * Rechecks are optimistic, not an atomic revocation/deletion publication barrier.
 */
async function withVerifiedRecordingJobInput(jobId, options, consume) {
    const base = new URL(options.storageUrl);
    const timeoutMs = options.ioTimeoutMs ?? 30000;
    if (base.protocol !== 'https:' || base.username || base.password || base.search || base.hash || base.pathname !== '/' ||
        !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000 ||
        typeof options.serviceRoleKey !== 'string' || !options.serviceRoleKey || /\s/.test(options.serviceRoleKey)) {
        throw new Error('Invalid recording verifier configuration');
    }
    const decode = (0, recording_audio_decoder_1.createFfmpegRecordingDecoder)(options.ffmpeg);
    const fetcher = options.fetch ?? fetch;
    try {
        options.signal?.throwIfAborted();
        const input = await (0, recording_job_input_1.loadRecordingJobInput)(jobId, { admin: options.admin, signal: options.signal, lease: options.lease });
        const revalidate = async (signal) => {
            options.signal?.throwIfAborted();
            signal?.throwIfAborted();
            await input.revalidate(signal);
            options.signal?.throwIfAborted();
            signal?.throwIfAborted();
        };
        const result = await (0, recording_merge_executor_1.withVerifiedRecordingMerge)(input.task, {
            signal: options.signal,
            tempRoot: options.tempRoot,
            maxInputBytes: recording_session_service_1.DEFAULT_MAX_RECORDING_INPUT_BYTES,
            readChunk: async (chunk) => (async function* () {
                await revalidate();
                const scope = ioScope(options.signal, timeoutMs);
                let response;
                let reader;
                try {
                    const key = input.storageObjectKeys[chunk.index];
                    // Only the closed, owner-bound ledger namespace supplies this path.
                    const url = `${base.origin}/storage/v1/object/audio-recordings/${key.split('/').map(encodeURIComponent).join('/')}`;
                    const pending = fetcher(url, { method: 'GET', redirect: 'error', cache: 'no-store',
                        headers: { Authorization: `Bearer ${options.serviceRoleKey}`, apikey: options.serviceRoleKey }, signal: scope.signal });
                    // A non-cooperative transport may return after timeout; it still owns a body to close.
                    void pending.then(late => { if (scope.signal.aborted)
                        void late.body?.cancel().catch(() => { }); }, () => { });
                    response = await scope.wait(pending);
                    scope.signal.throwIfAborted();
                    const length = response.headers.get('content-length');
                    const encoding = response.headers.get('content-encoding');
                    if (response.status !== 200 || !response.body || response.redirected ||
                        (length !== null && (!/^(0|[1-9][0-9]*)$/.test(length) || Number(length) !== chunk.byteSize)) ||
                        (encoding !== null && encoding !== 'identity'))
                        throw unavailable();
                    await scope.wait(revalidate(scope.signal));
                    reader = response.body.getReader();
                    while (true) {
                        const frame = await scope.wait(reader.read());
                        scope.signal.throwIfAborted();
                        if (frame.done)
                            break;
                        yield frame.value;
                    }
                    await scope.wait(revalidate(scope.signal));
                }
                finally {
                    scope.close();
                    await closeBody(response, reader);
                }
            })(),
            decodeAudio: async (path, mime, signal) => {
                await revalidate();
                return await decode(path, mime, signal);
            },
        }, async (artifact) => {
            await revalidate();
            const consumed = await consume(artifact, { revalidate });
            await revalidate();
            return consumed;
        });
        // The executor removes temporary files after its callback, which is another await.
        await revalidate();
        return result;
    }
    catch (error) {
        if ((0, recording_processing_error_1.isRecordingProcessingError)(error))
            throw error;
        // No provider body, private object path, credentials or decoder diagnostics escape.
        throw unavailable();
    }
}
