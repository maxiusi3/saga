"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prepareRecordingJobCandidateOutcome = prepareRecordingJobCandidateOutcome;
exports.prepareLeasedRecordingJobCandidate = prepareLeasedRecordingJobCandidate;
const node_crypto_1 = require("node:crypto");
const recording_job_verifier_1 = require("./recording-job-verifier");
const recording_job_worker_1 = require("./recording-job-worker");
const recording_output_candidate_1 = require("./recording-output-candidate");
const recording_candidate_storage_1 = require("./recording-candidate-storage");
/** Carries settled preparation evidence without deciding whether a failure is terminal. */
async function prepareRecordingJobCandidateOutcome(jobId, options, context) {
    let consumerStarted = false;
    try {
        const candidate = await (0, recording_job_verifier_1.withVerifiedRecordingJobInput)(jobId, { ...options, lease: context.getLease(), signal: context.signal }, async (artifact, input) => {
            // Once the callback begins even a branded processing error is uncertain:
            // reservation, storage, preparation or later cleanup may have run.
            consumerStarted = true;
            const rpc = { admin: options.admin, signal: context.signal, timeoutMs: context.rpcTimeoutMs };
            const reserved = await (0, recording_output_candidate_1.reserveRecordingOutputCandidate)(context.getLease(), (0, node_crypto_1.randomUUID)(), {
                byteSize: artifact.completion.outputByteSize, sha256: artifact.completion.outputSha256,
                mimeType: artifact.mimeType, durationMs: artifact.completion.durationMs,
            }, rpc);
            await (0, recording_candidate_storage_1.uploadAndVerifyRecordingCandidate)(artifact, reserved, { ...options, signal: context.signal, revalidate: input.revalidate });
            return await (0, recording_output_candidate_1.prepareRecordingOutputCandidate)(context.getLease(), reserved, rpc);
        });
        return { status: 'candidate_prepared', jobId, candidate, canClearLocalDrafts: false };
    }
    catch (error) {
        return { status: 'preparation_failed', error, consumerStarted };
    }
}
/** Preparation is durable private storage, not publication or terminal success. */
async function prepareLeasedRecordingJobCandidate(jobId, options) {
    const snapshot = { ...options, ffmpeg: { ...options.ffmpeg } };
    return (0, recording_job_worker_1.withRecordingJobLease)(jobId, snapshot, async (context) => {
        const outcome = await prepareRecordingJobCandidateOutcome(jobId, snapshot, context);
        if (outcome.status === 'preparation_failed')
            throw outcome.error;
        return outcome;
    });
}
