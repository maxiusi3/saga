import { randomUUID } from 'node:crypto'
import { withVerifiedRecordingJobInput } from './recording-job-verifier'
import { withRecordingJobLease } from './recording-job-worker'
import { reserveRecordingOutputCandidate, prepareRecordingOutputCandidate } from './recording-output-candidate'
import { uploadAndVerifyRecordingCandidate } from './recording-candidate-storage'

/** Preparation is durable private storage, not publication or terminal success. */
export async function prepareLeasedRecordingJobCandidate(jobId: string, options: Parameters<typeof withRecordingJobLease>[1]) {
  return withRecordingJobLease(jobId, options, async context => {
    const candidate = await withVerifiedRecordingJobInput(jobId, { ...options, lease: context.getLease(), signal: context.signal },
      async (artifact, input) => {
        const rpc = { admin: options.admin, signal: context.signal, timeoutMs: context.rpcTimeoutMs }
        const reserved = await reserveRecordingOutputCandidate(context.getLease(), randomUUID(), {
          byteSize: artifact.completion.outputByteSize, sha256: artifact.completion.outputSha256,
          mimeType: artifact.mimeType, durationMs: artifact.completion.durationMs,
        }, rpc)
        await uploadAndVerifyRecordingCandidate(artifact, reserved, { ...options, signal: context.signal, revalidate: input.revalidate })
        return await prepareRecordingOutputCandidate(context.getLease(), reserved, rpc)
      })
    return { status: 'candidate_prepared' as const, jobId, candidate, canClearLocalDrafts: false as const }
  })
}
