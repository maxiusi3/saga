# Recording candidate SQL probe

Run from repository root:

```sh
node experiments/pg17-recording-candidates/verify.mjs --without-migration
node experiments/pg17-recording-candidates/verify.mjs --sql-only
```

The first command intentionally fails on the missing exact candidate RPC, using
an actual service-role PostgreSQL invocation. Each execution writes a new UUID
run directory under `docs/research/evidence/2026-11-03-g1-worker-candidates/`.
Old harnesses and old evidence are never executed or rewritten.

Uses the pinned native PostgreSQL 17.4 runtime over a private Unix socket, exact
selected foundation DDL, full seal/lease/candidate migrations, and synthetic
identity prerequisites. Minimal `storage.buckets` and `storage.objects` fixtures
have RLS and intentionally broad client policies. They test PostgreSQL policy
composition, not real Supabase Storage API behavior, managed-schema ownership,
cloud TLS, deployment, backup coverage, or publication safety. Service-role SQL
sessions deliberately have no BYPASSRLS; Storage authority comes from fixture
policies, not a claim that live Storage runs this way.

Source snapshots and PostgreSQL logs are compressed and hashed in each run.
Cleanup stops the isolated cluster and removes its sockets and scratch tree.
Candidate persistence is not publication; G1 and push conditions remain false.
