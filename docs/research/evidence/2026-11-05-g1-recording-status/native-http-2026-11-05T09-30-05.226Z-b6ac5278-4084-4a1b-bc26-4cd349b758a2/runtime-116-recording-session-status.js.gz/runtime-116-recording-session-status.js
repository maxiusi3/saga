"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readRecordingSessionStatus = readRecordingSessionStatus;
const recording_status_validation_1 = require("./recording-status-validation");
function unavailable() { throw new Error('recording_status_unavailable'); }
/** One bounded snapshot read. A rejection never authorizes replay, recovery or cleanup. */
async function readRecordingSessionStatus(input, options) {
    let pinned, admin, signal, timeoutMs;
    try {
        (0, recording_status_validation_1.validateRecordingSessionStatusInput)(input);
        pinned = Object.freeze({ ...input });
        ({ admin, signal } = options);
        timeoutMs = options.timeoutMs ?? 5000;
        if (typeof window !== 'undefined' || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 60000 || signal?.aborted)
            unavailable();
    }
    catch {
        return unavailable();
    }
    const controller = new AbortController();
    const abort = () => controller.abort();
    let rejectAbort = () => { };
    const interrupted = new Promise((_, reject) => {
        rejectAbort = () => reject(new Error('recording_status_unavailable'));
        controller.signal.addEventListener('abort', rejectAbort, { once: true });
    });
    signal?.addEventListener('abort', abort, { once: true });
    const timer = setTimeout(abort, timeoutMs);
    try {
        const result = await Promise.race([admin.rpc('read_recording_session_snapshot', {
                p_actor_id: pinned.actorId, p_project_id: pinned.projectId, p_session_id: pinned.sessionId, p_manifest_sha256: pinned.manifestSha256,
            }).abortSignal(controller.signal).retry(false), interrupted]);
        if (controller.signal.aborted || signal?.aborted || !result || result.error)
            unavailable();
        return (0, recording_status_validation_1.validateRecordingSessionSnapshot)(result.data, pinned);
    }
    catch {
        return unavailable();
    }
    finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
        controller.signal.removeEventListener('abort', rejectAbort);
        abort();
    }
}
