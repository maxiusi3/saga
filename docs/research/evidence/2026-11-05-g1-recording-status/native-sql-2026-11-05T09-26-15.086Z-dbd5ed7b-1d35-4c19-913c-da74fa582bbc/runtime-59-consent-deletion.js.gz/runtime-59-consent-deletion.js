"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isActionAllowed = isActionAllowed;
exports.hasActiveConsent = hasActiveConsent;
exports.createDeletionRequest = createDeletionRequest;
exports.isDeletionBlocking = isDeletionBlocking;
exports.beginDeletionRequest = beginDeletionRequest;
exports.recordDeletionFailure = recordDeletionFailure;
exports.completeDeletionRequest = completeDeletionRequest;
exports.reapplyDeletionTombstone = reapplyDeletionTombstone;
function isActionAllowed(action, subject) {
    if (!subject.actorId.trim() || !subject.active || subject.isDeletionBlocked)
        return false;
    const isManager = subject.role === 'facilitator' || subject.isProjectOwner === true;
    switch (action) {
        case 'read_project':
            return subject.role === 'facilitator' || subject.role === 'storyteller' || subject.role === 'member';
        case 'manage_project':
        case 'family_share':
        case 'delete_story':
            return isManager;
        case 'record_own_story':
        case 'edit_own_story':
        case 'run_ai_for_own_story':
        case 'public_contribution':
            return subject.role === 'storyteller' && subject.storyOwnerId === subject.actorId;
        default:
            return false;
    }
}
function timestamp(value) {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
}
function hasActiveConsent(records, query) {
    const at = timestamp(query.at);
    if (at === null)
        return false;
    return records.some(record => {
        const granted = timestamp(record.grantedAt);
        const withdrawn = record.withdrawnAt === null ? null : timestamp(record.withdrawnAt);
        if (granted === null || (record.withdrawnAt !== null && withdrawn === null))
            return false;
        return record.grantorId === query.grantorId
            && record.subjectId === query.subjectId
            && record.purpose === query.purpose
            && record.policyVersion === query.policyVersion
            && record.provider === query.provider
            && record.region === query.region
            && granted <= at
            && (withdrawn === null || at < withdrawn);
    });
}
function requireText(value, label) {
    if (typeof value !== 'string' || !value.trim())
        throw new Error(`${label} is required`);
}
function requireTime(value, label) {
    if (timestamp(value) === null)
        throw new Error(`Invalid ${label}`);
}
function cloneRequest(request) {
    return { ...request, targets: request.targets.map(target => ({ ...target })) };
}
function createDeletionRequest(input) {
    requireText(input.id, 'Deletion request id');
    requireText(input.subjectId, 'Deletion subject');
    requireText(input.requestedBy, 'Deletion requester');
    requireTime(input.now, 'deletion request time');
    if (input.targets.length === 0)
        throw new Error('At least one deletion target is required');
    const ids = input.targets.map(target => {
        requireText(target.id, 'Deletion target id');
        requireText(target.kind, 'Deletion target kind');
        return target.id;
    });
    if (new Set(ids).size !== ids.length)
        throw new Error('Deletion targets must not contain duplicate ids');
    return {
        id: input.id,
        subjectId: input.subjectId,
        requestedBy: input.requestedBy,
        state: 'requested',
        tombstoneAt: input.now,
        attempt: 0,
        requestedAt: input.now,
        processingAt: null,
        completedAt: null,
        errorCode: null,
        targets: input.targets.map(target => ({ ...target, state: 'pending', errorCode: null })),
    };
}
function isDeletionBlocking(request) {
    return request.tombstoneAt !== null;
}
function beginDeletionRequest(request, now) {
    requireTime(now, 'deletion processing time');
    if (request.state !== 'requested' && request.state !== 'failed')
        throw new Error('Deletion request is not ready for processing');
    const next = cloneRequest(request);
    next.state = 'processing';
    next.attempt += 1;
    next.processingAt = now;
    next.completedAt = null;
    next.errorCode = null;
    next.targets = next.targets.map(target => target.state === 'failed' ? { ...target, state: 'pending', errorCode: null } : target);
    return next;
}
function recordDeletionFailure(request, now, errorCode) {
    requireTime(now, 'deletion failure time');
    requireText(errorCode, 'Deletion error code');
    if (request.state !== 'processing')
        throw new Error('Deletion request is not processing');
    return { ...cloneRequest(request), state: 'failed', errorCode, completedAt: null };
}
function completeDeletionRequest(request, now) {
    requireTime(now, 'deletion completion time');
    if (request.state !== 'processing')
        throw new Error('Deletion request is not processing');
    if (request.targets.some(target => target.state !== 'deleted' && target.state !== 'not_found')) {
        throw new Error('All deletion targets must be confirmed before completion');
    }
    return { ...cloneRequest(request), state: 'completed', completedAt: now, errorCode: null };
}
function reapplyDeletionTombstone(request, now) {
    requireTime(now, 'tombstone time');
    const next = cloneRequest(request);
    next.tombstoneAt = now;
    if (next.state === 'completed')
        next.state = 'failed';
    next.completedAt = null;
    next.errorCode = 'tombstone_reapplied_after_restore';
    return next;
}
