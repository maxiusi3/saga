"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildRecordingMergeTaskInput = buildRecordingMergeTaskInput;
exports.verifyRecordingMergeCompletion = verifyRecordingMergeCompletion;
const crypto_1 = require("crypto");
const processing_jobs_1 = require("./processing-jobs");
function required(value, label) {
    if (typeof value !== 'string' || value.trim() === '' || value !== value.trim()) {
        throw new Error(`${label} is required`);
    }
    return value;
}
function positiveSafeInteger(value, label) {
    if (!Number.isSafeInteger(value) || value <= 0) {
        throw new Error(`${label} must be a positive safe integer`);
    }
    return value;
}
function sha256(value, label) {
    if (!/^[a-f0-9]{64}$/i.test(value))
        throw new Error(`${label} must be a 64-character hex digest`);
    return value.toLowerCase();
}
function sessionPath(projectId, sessionId, index) {
    return `projects/${projectId}/sessions/${sessionId}/${index}`;
}
function cloneChunk(chunk) {
    return { ...chunk, sha256: chunk.sha256.toLowerCase() };
}
function validateChunk(chunk, projectId, sessionId, expectedIndex) {
    if (!Number.isSafeInteger(chunk.index) || chunk.index !== expectedIndex || chunk.index < 0) {
        throw new Error('recording chunks must be contiguous and ordered');
    }
    required(chunk.chunkId, 'chunk id');
    if (chunk.bucket !== 'audio-recordings')
        throw new Error('recording chunk bucket is invalid');
    required(chunk.objectKey, 'chunk object key');
    if (chunk.objectKey !== sessionPath(projectId, sessionId, chunk.index)) {
        throw new Error('recording chunk object is not bound to the project and session');
    }
    positiveSafeInteger(chunk.byteSize, 'chunk byte size');
    return {
        index: chunk.index,
        chunkId: chunk.chunkId,
        bucket: chunk.bucket,
        objectKey: chunk.objectKey,
        byteSize: chunk.byteSize,
        sha256: sha256(chunk.sha256, 'chunk sha256'),
    };
}
function normalizeChunks(chunks, projectId, sessionId) {
    if (!Array.isArray(chunks) || chunks.length === 0)
        throw new Error('recording merge requires chunks');
    const normalized = chunks
        .map(cloneChunk)
        .sort((left, right) => left.index - right.index)
        .map((chunk, index) => validateChunk(chunk, projectId, sessionId, index));
    const ids = new Set(normalized.map(chunk => chunk.chunkId));
    if (ids.size !== normalized.length)
        throw new Error('recording chunks must have unique ids');
    return normalized;
}
function canonicalChunks(chunks) {
    return JSON.stringify(chunks.map(chunk => [
        chunk.index, chunk.chunkId, chunk.bucket, chunk.objectKey, chunk.byteSize, chunk.sha256,
    ]));
}
function manifestDigest(chunks) {
    return (0, crypto_1.createHash)('sha256').update(canonicalChunks(chunks)).digest('hex');
}
function buildRecordingMergeTaskInput(input) {
    const projectId = required(input.projectId, 'project id');
    const sessionId = required(input.sessionId, 'session id');
    const assetId = required(input.assetId, 'asset id');
    const processorVersion = required(input.processorVersion, 'processor version');
    const parameterVersion = required(input.parameterVersion, 'parameter version');
    const mimeType = required(input.mimeType, 'mime type');
    positiveSafeInteger(input.inputVersion, 'input version');
    const chunks = normalizeChunks(input.chunks, projectId, sessionId);
    const totalInputBytes = chunks.reduce((total, chunk) => total + chunk.byteSize, 0);
    const baseIdempotency = (0, processing_jobs_1.buildProcessingJobIdempotencyKey)({
        projectId,
        assetId,
        inputVersion: input.inputVersion,
        jobType: 'recording_merge',
        processorVersion,
        modelConfigVersion: 'none',
        parameterVersion,
    });
    const idempotencyKey = `${baseIdempotency}:mime=${mimeType}:session=${sessionId}:chunks=${manifestDigest(chunks)}`;
    return {
        projectId,
        sessionId,
        assetId,
        inputVersion: input.inputVersion,
        jobType: 'recording_merge',
        processorVersion,
        parameterVersion,
        mimeType,
        chunks,
        totalInputBytes,
        idempotencyKey,
    };
}
function sameChunks(expected, actual, projectId, sessionId) {
    try {
        return canonicalChunks(expected) === canonicalChunks(normalizeChunks(actual, projectId, sessionId));
    }
    catch {
        return false;
    }
}
function verifyRecordingMergeCompletion(input, evidence) {
    if (evidence.projectId !== input.projectId)
        throw new Error('recording merge project does not match asset');
    if (evidence.sessionId !== input.sessionId)
        throw new Error('recording merge session does not match task');
    if (evidence.assetId !== input.assetId)
        throw new Error('recording merge asset does not match task');
    if (evidence.decoded !== true)
        throw new Error('merged recording must be decoded successfully');
    positiveSafeInteger(evidence.durationMs, 'decoded duration');
    positiveSafeInteger(evidence.outputByteSize, 'output byte size');
    const outputSha256 = sha256(evidence.outputSha256, 'output sha256');
    if (!sameChunks(input.chunks, evidence.chunks, input.projectId, input.sessionId)) {
        throw new Error('recording merge chunk evidence does not match task');
    }
    return {
        assetId: input.assetId,
        state: 'ready',
        durationMs: evidence.durationMs,
        byteSize: evidence.outputByteSize,
        sha256: outputSha256,
    };
}
