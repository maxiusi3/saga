import { NextRequest, NextResponse } from 'next/server'
import { getAuthenticatedUser } from '@/lib/server/auth'
import { safeExportFilename } from '@/lib/media-assets'
import { verifyMediaObjectStream } from '@/lib/server/media-asset-verifier'
import { requireProjectAccess } from '@/lib/server/project-access'
import { getSupabaseAdmin } from '@/lib/supabase'
import { requireCurrentMediaAsset } from '@/lib/server/media-asset-guard'
import { withMediaHeaders } from '@/lib/server/media-access'

export const runtime = 'nodejs'

function reply(body: unknown, status: number, headers: Headers) {
  return withMediaHeaders(NextResponse.json(body, { status }), headers)
}

function maxBytesFor(kind: string): number {
  return kind === 'original_audio' ? 100 * 1024 * 1024 : 5 * 1024 * 1024
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ assetId: string }> },
) {
  const auth = await getAuthenticatedUser(request)
  if (!auth.ok) {
    auth.response.headers.set('Cache-Control', 'no-store')
    return auth.response
  }
  if (process.env.MEDIA_ASSETS_ENABLED !== 'true') return reply({ error: 'Media assets are not enabled' }, 404, auth.headers)

  const { assetId } = await params
  if (!assetId || !/^[A-Za-z0-9_-]{3,128}$/.test(assetId)) return reply({ error: 'Invalid asset id' }, 400, auth.headers)

  let admin: ReturnType<typeof getSupabaseAdmin>
  try { admin = getSupabaseAdmin() } catch { return reply({ error: 'Database service not configured' }, 503, auth.headers) }
  try {
    const { data: asset, error: loadError } = await admin.from('media_assets')
      .select('*').eq('id', assetId).maybeSingle()
    if (loadError) return reply({ error: 'Failed to load asset' }, 500, auth.headers)
    if (!asset) return reply({ error: 'Asset not found' }, 404, auth.headers)
    const access = await requireProjectAccess(asset.project_id, auth.user)
    if (!access.ok) {
      const body = await access.response.json()
      return reply(body, access.response.status, auth.headers)
    }

    if (asset.tombstone_at != null || !['pending_upload', 'uploaded', 'verifying', 'ready'].includes(asset.state)) {
      return reply({ error: 'Asset is not eligible for verification' }, 409, auth.headers)
    }
    const checkDeletion = async () => {
      const subjects = [asset.id, asset.story_id].filter((id): id is string => typeof id === 'string')
      const { data, error } = await admin.from('deletion_requests')
        .select('subject_id, tombstone_at').eq('project_id', asset.project_id)
        .in('subject_id', subjects).not('tombstone_at', 'is', null)
      if (error || !Array.isArray(data)) return reply({ error: 'Failed to verify deletion status' }, 500, auth.headers)
      return data.length ? reply({ error: 'Asset is not eligible for verification' }, 409, auth.headers) : null
    }
    const deleted = await checkDeletion()
    if (deleted) return deleted
    if (asset.state === 'ready' || asset.state === 'verifying') {
      const current = await requireCurrentMediaAsset(admin, auth.user, asset, ['ready', 'verifying'])
      if (!current.ok) return withMediaHeaders(current.response, auth.headers)
      return reply({ asset }, asset.state === 'ready' ? 200 : 202, auth.headers)
    }
    const updateAsset = (patch: Record<string, unknown>) => {
      const update = admin.from('media_assets').update(patch)
        .eq('id', asset.id).eq('project_id', asset.project_id)
        .eq('bucket', asset.bucket).eq('object_key', asset.object_key).eq('kind', asset.kind)
        .eq('state', asset.state).eq('version', asset.version)
      // Only shipped columns can be CAS predicates. Ledger checks are separate,
      // not an atomic tombstone exclusion across the two tables.
      return (asset.story_id == null ? update.is('story_id', null) : update.eq('story_id', asset.story_id))
        .select('*').single()
    }

    const storage = admin.storage.from(asset.bucket)
    const { data: info, error: infoError } = await storage.info(asset.object_key)
    if (infoError || !info) return reply({ error: 'Uploaded object not found' }, 404, auth.headers)

    if (typeof info.size === 'number' && typeof asset.byte_size === 'number' && info.size !== asset.byte_size) {
      const current = await requireCurrentMediaAsset(admin, auth.user, asset, ['pending_upload', 'uploaded'])
      if (!current.ok) return withMediaHeaders(current.response, auth.headers)
      const { data: quarantined, error: updateError } = await updateAsset({
        state: 'quarantined',
        verification_error: 'integrity_mismatch',
        byte_size: info.size,
        verified_at: new Date().toISOString(),
      })
      if (updateError || !quarantined) return reply({ error: 'Asset changed while verification was running' }, 409, auth.headers)
      const final = await requireCurrentMediaAsset(admin, auth.user, quarantined, ['quarantined'])
      if (!final.ok) return withMediaHeaders(final.response, auth.headers)
      return reply({ error: 'Uploaded object failed verification', asset: quarantined }, 409, auth.headers)
    }

    const { data: stream, error: streamError } = await storage.download(asset.object_key).asStream()
    if (streamError || !stream) return reply({ error: 'Failed to read uploaded object' }, 502, auth.headers)
    const result = await verifyMediaObjectStream(stream, {
      expectedBytes: typeof asset.byte_size === 'number' ? asset.byte_size : undefined,
      expectedSha256: typeof asset.sha256 === 'string' ? asset.sha256 : undefined,
      contentType: info.contentType,
      expectedMimeType: asset.mime_type,
      maxBytes: maxBytesFor(asset.kind),
    })
    const current = await requireCurrentMediaAsset(admin, auth.user, asset, ['pending_upload', 'uploaded'])
    if (!current.ok) return withMediaHeaders(current.response, auth.headers)
    if (!result.ok) {
      const { data: quarantined, error: updateError } = await updateAsset({
        state: 'quarantined',
        verification_error: result.reason,
        byte_size: result.byteSize,
        sha256: result.sha256 ?? null,
        verified_at: new Date().toISOString(),
      })
      if (updateError || !quarantined) return reply({ error: 'Asset changed while verification was running' }, 409, auth.headers)
      const final = await requireCurrentMediaAsset(admin, auth.user, quarantined, ['quarantined'])
      if (!final.ok) return withMediaHeaders(final.response, auth.headers)
      return reply({ error: 'Uploaded object failed verification', asset: quarantined }, result.reason === 'too_large' ? 413 : 409, auth.headers)
    }

    const nextState = asset.kind === 'original_image' ? 'ready' : 'verifying'
    const { data: verified, error: updateError } = await updateAsset({
      state: nextState,
      byte_size: result.byteSize,
      sha256: result.sha256,
      original_filename: safeExportFilename(asset.original_filename),
      verified_at: new Date().toISOString(),
      content_verified_at: asset.kind === 'original_image' ? new Date().toISOString() : null,
      verification_error: null,
    })
    if (updateError || !verified) return reply({ error: 'Asset changed while verification was running' }, 409, auth.headers)
    const final = await requireCurrentMediaAsset(admin, auth.user, verified, [nextState])
    if (!final.ok) return withMediaHeaders(final.response, auth.headers)
    return reply({ asset: verified }, nextState === 'ready' ? 200 : 202, auth.headers)
  } catch {
    return reply({ error: 'Asset verification is unavailable' }, 500, auth.headers)
  }
}
