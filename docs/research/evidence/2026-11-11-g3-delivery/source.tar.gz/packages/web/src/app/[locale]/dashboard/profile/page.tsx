'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { createBrowserClient } from '@supabase/ssr'
import { User } from '@supabase/supabase-js'
import { Camera, Save } from 'lucide-react'
import { useTranslations, useLocale } from 'next-intl'

interface UserProfile {
  full_name: string
  email: string
  avatar_url?: string
  phone?: string
  bio?: string
  joined_date: string
  total_projects: number
  total_stories: number
}

export default function ProfilePage() {
  const t = useTranslations('profile')
  const locale = useLocale()
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)
  
  const [formData, setFormData] = useState({
    full_name: '',
    phone: '',
    bio: ''
  })

  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        setUser(user)

        if (user) {
          // Load real profile data from Supabase
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', user.id)
            .single()

          // Count user's projects (as owner or member)
          const { count: projectCount } = await supabase
            .from('project_roles')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id)
            .eq('status', 'active')

          // Count user's stories
          const { count: storyCount } = await supabase
            .from('stories')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id)

          const realProfile: UserProfile = {
            full_name: profile?.name || user.user_metadata?.full_name || user.email || '',
            email: user.email || '',
            avatar_url: profile?.avatar_url || user.user_metadata?.avatar_url,
            phone: profile?.phone || '',
            bio: profile?.bio || '',
            joined_date: user.created_at || new Date().toISOString(),
            total_projects: projectCount || 0,
            total_stories: storyCount || 0
          }

          setProfile(realProfile)
          setFormData({
            full_name: realProfile.full_name,
            phone: realProfile.phone || '',
            bio: realProfile.bio || ''
          })
        }
      } catch (error) {
        console.error('Error loading profile:', error)
      } finally {
        setLoading(false)
      }
    }

    loadProfile()
  }, [supabase])

  const handleSave = async () => {
    if (!user || !profile) return

    setSaving(true)
    try {
      // Update profile in Supabase
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          user_id: user.id,
          display_name: formData.full_name,
          phone: formData.phone,
          user_metadata: {
            ...profile,
            full_name: formData.full_name,
            bio: formData.bio
          },
          updated_at: new Date().toISOString()
        })

      if (error) throw error

      setProfile({
        ...profile,
        full_name: formData.full_name,
        phone: formData.phone,
        bio: formData.bio
      })

      setIsEditing(false)
    } catch (error) {
      console.error('Error updating profile:', error)
      alert('Failed to update profile. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  const handleCancel = () => {
    if (profile) {
      setFormData({
        full_name: profile.full_name,
        phone: profile.phone || '',
        bio: profile.bio || ''
      })
    }
    setIsEditing(false)
  }

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="h-8 w-48 bg-muted rounded animate-pulse"></div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-muted rounded-lg animate-pulse"></div>
          ))}
        </div>
      </div>
    )
  }

  if (!user || !profile) {
    return (
      <div className="text-center py-16">
        <h1 className="text-2xl font-bold text-foreground">{t('notFound')}</h1>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-foreground">{t('title')}</h1>
        {!isEditing && (
          <Button variant="outline" onClick={() => setIsEditing(true)}>
            {t('editProfile')}
          </Button>
        )}
      </div>

      {/* Profile Card */}
      <Card className="p-8">
        <div className="space-y-6">
          {/* Avatar Section */}
          <div className="flex items-center space-x-6">
            <div className="relative">
              <Avatar className="h-24 w-24">
                <AvatarImage src={profile.avatar_url} />
                <AvatarFallback className="text-2xl">
                  {profile.full_name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {isEditing && (
                <Button
                  variant="outline"
                  size="icon"
                  className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full"
                >
                  <Camera className="h-4 w-4" />
                </Button>
              )}
            </div>
            
            <div className="space-y-1">
              <h2 className="text-2xl font-semibold text-foreground">
                {profile.full_name}
              </h2>
              <p className="text-muted-foreground">{profile.email}</p>
              <p className="text-sm text-muted-foreground">
                {t('memberSince')} {new Date(profile.joined_date).toLocaleDateString(locale, {
                  month: 'long',
                  year: 'numeric'
                })}
              </p>
            </div>
          </div>

          <Separator />

          {/* Profile Form */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="full_name">{t('form.fullName')}</Label>
                {isEditing ? (
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    className="mt-1"
                  />
                ) : (
                  <div className="mt-1 text-foreground">{profile.full_name}</div>
                )}
              </div>

              <div>
                <Label htmlFor="email">{t('form.email')}</Label>
                <div className="mt-1 text-muted-foreground">{profile.email}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {t('form.emailCannotChange')}
                </p>
              </div>
            </div>

            <div>
              <Label htmlFor="phone">{t('form.phone')}</Label>
              {isEditing ? (
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder={t('form.phonePlaceholder')}
                  className="mt-1"
                />
              ) : (
                <div className="mt-1 text-foreground">
                  {profile.phone || t('form.notProvided')}
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="bio">{t('form.bio')}</Label>
              {isEditing ? (
                <textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  placeholder={t('form.bioPlaceholder')}
                  rows={3}
                  className="mt-1 w-full px-3 py-2 border border-border rounded-md shadow-sm placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-primary"
                />
              ) : (
                <div className="mt-1 text-foreground">
                  {profile.bio || t('form.noBio')}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          {isEditing && (
            <div className="flex space-x-3 pt-4">
              <Button
                variant="default"
                onClick={handleSave}
                disabled={saving}
              >
                <Save className="h-4 w-4 mr-2" />
                {saving ? t('saving') : t('saveChanges')}
              </Button>
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={saving}
              >
                {t('cancel')}
              </Button>
            </div>
          )}
        </div>
      </Card>

      {/* Stats Card */}
      <Card className="p-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">{t('stats.title')}</h3>
          
          <div className="grid grid-cols-2 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">
                {profile.total_projects}
              </div>
              <div className="text-sm text-muted-foreground">
                {t('stats.activeProjects')}
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">
                {profile.total_stories}
              </div>
              <div className="text-sm text-muted-foreground">
                {t('stats.storiesShared')}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Account Settings */}
      <Card className="p-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">{t('account.title')}</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <div>
                <div className="font-medium text-foreground">{t('account.emailNotifications')}</div>
                <div className="text-sm text-muted-foreground">
                  {t('account.emailNotificationsDesc')}
                </div>
              </div>
              <Badge variant="secondary">{t('account.enabled')}</Badge>
            </div>
            
            <div className="flex justify-between items-center">
              <div>
                <div className="font-medium text-foreground">{t('account.privacySettings')}</div>
                <div className="text-sm text-muted-foreground">
                  {t('account.privacySettingsDesc')}
                </div>
              </div>
              <Button variant="outline" size="sm">
                {t('account.manage')}
              </Button>
            </div>
            
            <div className="flex justify-between items-center">
              <div>
                <div className="font-medium text-foreground">{t('account.dataExport')}</div>
                <div className="text-sm text-muted-foreground">
                  {t('account.dataExportDesc')}
                </div>
              </div>
              <Button variant="outline" size="sm">
                {t('account.export')}
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}
