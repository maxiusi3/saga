import React, { useState, useEffect } from 'react'
import { Card } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Circle, Clock } from 'lucide-react'
import { ChapterProgress as ChapterProgressType } from '@saga/shared'
import { chapterService } from '@/lib/chapters'
import { getDefaultServicePlan, formatServiceStatus, getServiceProgress } from '@saga/shared/config/service-plans'

interface ChapterProgressProps {
  projectId: string
  className?: string
  projectCreatedAt?: string
  servicePlanId?: string
}

export function ChapterProgress({
  projectId,
  className,
  projectCreatedAt,
  servicePlanId
}: ChapterProgressProps) {
  const [progress, setProgress] = useState<ChapterProgressType[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchProgress()
  }, [projectId])

  const fetchProgress = async () => {
    try {
      setLoading(true)
      setError(null)
      const progressData = await chapterService.getProjectChapterProgress(projectId)
      setProgress(progressData)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch chapter progress')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card className={`p-6 ${className}`}>
        <div className="space-y-4">
          <div className="h-6 bg-muted rounded animate-pulse" />
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="space-y-2">
                <div className="h-4 bg-muted rounded animate-pulse" />
                <div className="h-2 bg-muted rounded animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      </Card>
    )
  }

  if (error) {
    return (
      <Card className={`p-6 ${className}`}>
        <div className="text-center text-muted-foreground">
          <p>Failed to load chapter progress</p>
          <button 
            onClick={fetchProgress}
            className="mt-2 text-primary hover:underline"
          >
            Try again
          </button>
        </div>
      </Card>
    )
  }



  // 计算基于时间的服务期进度
  const calculateTimeProgress = () => {
    if (!projectCreatedAt) return null

    const servicePlan = getDefaultServicePlan() // 可以后续根据 servicePlanId 获取具体计划
    const startDate = new Date(projectCreatedAt)
    const endDate = new Date(startDate.getTime() + servicePlan.durationDays * 24 * 60 * 60 * 1000)

    const progress = getServiceProgress(startDate, endDate)
    const status = formatServiceStatus(endDate)

    return {
      progress,
      endDate,
      status: status.status,
      message: status.message,
      daysRemaining: status.daysRemaining,
      planName: servicePlan.name
    }
  }

  const timeProgress = calculateTimeProgress()

  return (
    <Card className={`p-6 ${className}`}>
      <div className="space-y-6">
        {/* Service Period Progress */}
        {timeProgress && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Service Period
              </h3>
              <Badge variant={
                timeProgress.status === 'expired' ? "destructive" :
                timeProgress.status === 'expiring_soon' ? "secondary" :
                "outline"
              }>
                {timeProgress.status === 'expired' ? 'Expired' : `${timeProgress.daysRemaining} days left`}
              </Badge>
            </div>
            <Progress
              value={timeProgress.progress}
              className="h-2"
              indicatorClassName={
                timeProgress.status === 'expired' ? 'bg-red-500' :
                timeProgress.status === 'expiring_soon' ? 'bg-yellow-500' :
                'bg-primary'
              }
            />
            <p className="text-sm text-muted-foreground">
              {timeProgress.planName} • {timeProgress.message}
            </p>
          </div>
        )}



        {/* Chapter Details */}
        <div className="space-y-4">
          <h4 className="font-medium text-foreground">Chapters</h4>
          <div className="space-y-3">
            {progress.map((chapterProgress) => {
              const isActive = chapterProgress.is_current

              return (
                <div key={chapterProgress.chapter.id} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {isActive ? (
                        <Clock className="h-4 w-4 text-primary" />
                      ) : (
                        <Circle className="h-4 w-4 text-muted-foreground" />
                      )}
                      <span className={`font-medium ${
                        isActive ? 'text-primary' : 'text-foreground'
                      }`}>
                        {chapterProgress.chapter.name}
                      </span>
                      {isActive && (
                        <Badge variant="default" className="text-xs">
                          Current
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {chapterProgress.stories_count > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {chapterProgress.stories_count} stories
                        </Badge>
                      )}
                    </div>
                  </div>

                  {chapterProgress.chapter.description && (
                    <p className="text-xs text-muted-foreground pl-6">
                      {chapterProgress.chapter.description}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Summary Stats */}
        <div className="pt-4 border-t border-border">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-primary">
                {progress.filter(p => p.is_current).length}
              </div>
              <div className="text-xs text-muted-foreground">Active Chapters</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">
                {progress.reduce((sum, p) => sum + p.stories_count, 0)}
              </div>
              <div className="text-xs text-muted-foreground">Total Stories</div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  )
}
