import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { jsonWithRateLimit, requireAiRequest } from '@/lib/server/ai-guard'
import { getTextAiConfig } from '@/lib/server/text-ai-config'
import { InvalidAIResponseError, parseGeneratedContent } from '@/lib/ai-response'

function createTextAiClient() {
  const config = getTextAiConfig()
  if (!config) return null

  return {
    client: new OpenAI({
      apiKey: config.apiKey,
      baseURL: config.baseURL,
      defaultHeaders: {
        'HTTP-Referer': process.env.NEXT_PUBLIC_WEB_URL || 'http://localhost:3000',
        'X-Title': 'Saga Family Biography Platform'
      }
    }),
    model: config.model,
  }
}

export async function POST(request: NextRequest) {
  const guard = await requireAiRequest(request, 'generate-content')
  if (!guard.ok) return guard.response

  try {
    const textAi = createTextAiClient()
    if (!textAi) {
      return jsonWithRateLimit(
        { error: 'Text AI API key not configured' },
        guard.headers,
        500
      )
    }

    const body = await request.json()
    const { transcript, prompt, language = 'en' } = body

    if (!transcript || transcript.trim().length === 0) {
      return jsonWithRateLimit(
        { error: 'No transcript provided' },
        guard.headers,
        400
      )
    }

    console.log(`Generating AI content for transcript (${transcript.length} chars) in language: ${language}`)

    // Language-specific instructions
    const languageInstructions: Record<string, string> = {
      'zh-CN': '请用中文回复。',
      'zh-TW': '請用繁體中文回覆。',
      'en': 'Please respond in English.',
      'ja': '日本語で返信してください。',
      'ko': '한국어로 응답해주세요.',
      'es': 'Por favor responde en español.',
      'fr': 'Veuillez répondre en français.',
      'de': 'Bitte antworten Sie auf Deutsch.',
      'pt': 'Por favor, responda em português.'
    }

    const languageInstruction = languageInstructions[language] || languageInstructions['en']

    // Create system prompt for story analysis
    const systemPrompt = `You are an expert storyteller and family historian. Your task is to analyze personal stories and create meaningful titles, summaries, and follow-up questions that help preserve family memories.

Guidelines:
- Create titles that are specific, emotional, and memorable
- Write summaries that capture the essence and emotional significance
- Generate follow-up questions that encourage deeper storytelling
- Be respectful and sensitive to personal experiences
- Focus on the human elements and emotional connections
- Keep language warm and conversational
- IMPORTANT: Respond in the SAME LANGUAGE as the transcript provided

Response format should be valid JSON with these fields:
- title: A compelling, specific title (max 60 characters)
- summary: A warm, engaging summary (2-3 sentences)
- followUpQuestions: Optional array of up to 4 thoughtful questions; omit if none are useful
- confidence: Optional self-reported number between 0 and 1; omit if unknown`

    // Create user prompt with the transcript
    const userPrompt = `${languageInstruction}

Please analyze this personal story and generate appropriate content IN THE SAME LANGUAGE as the transcript:

${prompt ? `Story context/prompt: ${prompt}\n\n` : ''}Story transcript:
"${transcript}"

Generate a title, summary, and follow-up questions that would help this person share more meaningful memories. Remember to use the SAME LANGUAGE as the transcript above.`

    console.log(`Calling text AI API with model: ${textAi.model}`)

    const completion = await textAi.client.chat.completions.create({
      model: textAi.model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.7, // Balanced creativity and consistency
      max_tokens: 800,
      response_format: { type: 'json_object' }
    })

    const responseText = completion.choices[0]?.message?.content
    if (!responseText) {
      console.error('No response content from OpenRouter API')
      throw new Error('No response from OpenAI')
    }

    console.log('AI content generation completed successfully')

    // Parse the JSON response
    let aiContent
    try {
      aiContent = JSON.parse(responseText)
    } catch (parseError) {
      console.error('Failed to parse AI response:', parseError)
      throw new InvalidAIResponseError()
    }

    // Validate and sanitize the response
    const result = parseGeneratedContent(aiContent)

    // Ensure title is not too long
    if (result.title.length > 60) {
      result.title = result.title.substring(0, 57) + '...'
    }

    return jsonWithRateLimit(result, guard.headers)

  } catch (error: any) {
    if (error instanceof InvalidAIResponseError) {
      return jsonWithRateLimit({ error: 'Invalid response from AI service' }, guard.headers, 502)
    }
    console.error('AI content generation error:', error)
    console.error('Error details:', {
      message: error.message,
      status: error.status,
      code: error.code,
      type: error.type,
      errorObject: error.error
    })

    // Handle specific OpenRouter/OpenAI errors
    if (error?.error?.type === 'invalid_request_error') {
      return jsonWithRateLimit(
        { error: 'Invalid request to AI service', details: error.message },
        guard.headers,
        400
      )
    }

    if (error?.error?.code === 'rate_limit_exceeded' || error?.status === 429) {
      return jsonWithRateLimit(
        { error: 'Rate limit exceeded. Please try again later.' },
        guard.headers,
        429
      )
    }

    if (error?.error?.code === 'insufficient_quota' || error?.status === 402) {
      return jsonWithRateLimit(
        { error: 'OpenRouter quota exceeded. Please check your billing.' },
        guard.headers,
        402
      )
    }

    // Handle timeout errors
    if (error.message?.includes('timeout') || error.code === 'ETIMEDOUT') {
      return jsonWithRateLimit(
        { error: 'Request timeout. Please try again.' },
        guard.headers,
        504
      )
    }

    // Generic error response
    return jsonWithRateLimit(
      { 
        error: 'AI content generation failed. Please try again.',
        details: process.env.NODE_ENV === 'development' ? error.message : undefined
      },
      guard.headers,
      500
    )
  }
}

// Handle OPTIONS request for CORS
export async function OPTIONS() {
  const origin = process.env.NEXT_PUBLIC_WEB_URL || 'http://localhost:3000'

  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  })
}
