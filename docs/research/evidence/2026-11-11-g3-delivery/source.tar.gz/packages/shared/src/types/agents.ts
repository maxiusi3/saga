export const AGENT_TYPES = ['interview', 'editor_librarian', 'wiki_editor'] as const
export type AgentType = (typeof AGENT_TYPES)[number]

export const AGENT_RUN_STATUSES = ['pending', 'running', 'completed', 'failed'] as const
export type AgentRunStatus = (typeof AGENT_RUN_STATUSES)[number]

export const AGENT_REVIEW_STATUSES = ['unreviewed', 'approved', 'rejected', 'edited'] as const
export type AgentReviewStatus = (typeof AGENT_REVIEW_STATUSES)[number]

export const INTERVENTION_LEVELS = ['off', 'low', 'high'] as const
export type InterventionLevel = (typeof INTERVENTION_LEVELS)[number]

export const INTERVIEW_EVENT_KINDS = [
  'opening',
  'warmup',
  'prior_story_recap',
  'gentle_probe',
  'transition',
  'emotional_support',
  'closing',
] as const
export type InterviewEventKind = (typeof INTERVIEW_EVENT_KINDS)[number]

export const STORY_ELEMENT_TYPES = [
  'time',
  'place',
  'person',
  'event',
  'theme',
  'emotion',
  'decision',
  'consequence',
  'reflection',
] as const
export type StoryElementType = (typeof STORY_ELEMENT_TYPES)[number]

export interface AgentRun {
  id: string
  agent_type: AgentType
  status: AgentRunStatus
  project_id: string | null
  story_id: string | null
  interview_session_id: string | null
  content_hash: string | null
  input: Record<string, unknown>
  output: Record<string, unknown> | null
  model: string | null
  error: string | null
  started_at: string
  completed_at: string | null
  created_by: string
}

export interface AgentArtifact {
  id: string
  agent_run_id: string
  project_id: string
  story_id: string | null
  artifact_type:
    | 'host_intervention'
    | 'standalone_story'
    | 'story_summary'
    | 'follow_up_questions'
    | 'story_elements'
    // Phase 2 public archive artifact types require the Phase 2 DB migration before persistence.
    | 'anonymized_contribution_preview'
    | 'wiki_event_candidate'
    | 'wiki_event_draft'
  payload: Record<string, unknown>
  source_refs: AgentSourceRef[]
  review_status: AgentReviewStatus
  confidence: number
  created_at: string
  updated_at: string
}

export interface AgentSourceRef {
  source_type: 'transcript' | 'story' | 'interview_event' | 'media'
  source_id: string
  start_offset?: number
  end_offset?: number
  quote?: string
}

export interface InterviewSession {
  id: string
  project_id: string
  storyteller_id: string
  prompt_text: string | null
  recording_mode: 'deep_dive' | 'chat'
  intervention_level: InterventionLevel
  status: 'active' | 'completed' | 'abandoned'
  started_at: string
  completed_at: string | null
}

export interface InterviewEvent {
  id: string
  interview_session_id: string
  project_id: string
  storyteller_id: string
  event_kind: InterviewEventKind
  intervention_level: InterventionLevel
  trigger_reason: string
  prompt_text: string
  transcript_window: string | null
  transcript_start_offset: number | null
  transcript_end_offset: number | null
  accepted: boolean | null
  created_at: string
}

export interface StoryElement {
  id: string
  project_id: string
  story_id: string
  agent_run_id: string
  element_type: StoryElementType
  value: string
  normalized_value: string | null
  source_quote: string
  source_start_offset: number | null
  source_end_offset: number | null
  confidence: number
  review_status: AgentReviewStatus
  created_at: string
  updated_at: string
}

export const PROVENANCE_VERIFICATION_STATUSES = [
  'verified',
  'unverified_rejected',
  'family_supplement',
  'disputed',
  'pending_review',
  'invalidated',
] as const
export type ProvenanceVerificationStatus = (typeof PROVENANCE_VERIFICATION_STATUSES)[number]

export const MEMORY_ATTRIBUTION_KINDS = [
  'storyteller_memory',
  'external_corroborated',
  'family_supplement',
  'disputed_memory',
] as const
export type MemoryAttributionKind = (typeof MEMORY_ATTRIBUTION_KINDS)[number]

export const REVIEW_DECISION_KINDS = [
  'unreviewed',
  'accepted',
  'modified',
  'disputed',
  'skipped',
  'rejected',
] as const
export type ReviewDecisionKind = (typeof REVIEW_DECISION_KINDS)[number]

