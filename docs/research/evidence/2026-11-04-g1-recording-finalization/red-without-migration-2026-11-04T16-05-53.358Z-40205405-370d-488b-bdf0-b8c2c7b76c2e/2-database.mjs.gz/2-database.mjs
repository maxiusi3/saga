export async function databaseScenarios() {}
